export interface Invitado {
  id: string
  name: string
  tableNumber: string
  validFor: string
}