export interface Item {
  name: string;
  color: string;
  url: string;
}