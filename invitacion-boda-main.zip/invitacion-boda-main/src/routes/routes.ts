export const routeHome = "/"
export const routeMuestrasDeAfecto = "/muestras-de-afecto"
export const routeDireccion = "/direccion"
export const routeError = "/*"
export const routeInitInvitado = (id: string) => `/invitacion/${id}`